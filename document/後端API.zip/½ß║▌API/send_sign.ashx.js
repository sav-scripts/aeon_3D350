var send_data =
{
    "name": "John",
    "sid": "H123456789",
    "birth": "1999/3/3",
    "phone": "0955666555",
    "email": "sss@ddd.ccc",
    "q_event": "2015/6/7 台北地區", // 選擇場次
    "q_time": "PM13:30~14:40",   // 選擇時段
    "q_have_licence": "是", // 是否有大型重型機車駕照
    "q_aeon_friend": "是", // 是否為AEON車友
    "q_aeon_type": "Elite300i" // 目前騎乘機型 (這項只有在 q_aeon_friend 選"是"時會給值, 選否得話就是空值)
};

var recive_data =
{
    "res": "ok"
};