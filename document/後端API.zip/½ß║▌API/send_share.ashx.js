var send_data =
{
    "name": "John",
    "phone": "0955666555",
    "email": "sss@ddd.ccc",
    "address_county":"台北市",
    "address_zone":"士林區",
    "address_detail":"xx路xx巷xx號"
};

var recive_data =
{
    "res": "ok"
};